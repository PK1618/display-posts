import React, { useState } from "react";
import Posts from "./components/Posts";
import "react-tabs/style/react-tabs.css";
import classes from "./App.module.css";
import { FaRegFrown } from "react-icons/fa";

function App() {
  const [postsMaster, setPostsMaster] = useState([]);
  const [loading, setLoading] = useState(false);
  const [resetPosts, setResetPosts] = useState([]);

  async function myPosts() {
    setLoading(true);
    const response = await fetch("https://jsonplaceholder.typicode.com/posts");
    const data = await response.json();
    data.map(
      d =>
        (d.category =
          d.id % 3 === 0 && d.id % 5 === 0
            ? "magic"
            : d.id % 3 === 0
            ? "thirds"
            : d.id % 5 === 0
            ? "fifths"
            : "others")
    );
    const transformedMytData = data.map(tData => {
      return {
        userId: tData.userId,
        title: tData.title,
        id: tData.id,
        category: tData.category,
        body: tData.body
      };
    });
    setPostsMaster(transformedMytData);
    setResetPosts(transformedMytData);
    setLoading(false);
  }
  const deleteButtonHandler = id => {
    const filteredPosts = postsMaster.filter(post => post.id !== id);
    setPostsMaster(filteredPosts);
  };

  const onResetPostsHandler = () => {
    setPostsMaster(resetPosts);
  };

  const headers = ["OTHERS", "THIRDS", "FIFTHS", "MAGIC"];
  let content;
  if (loading) {
    content = <p>Loading...</p>;
  }
  if (postsMaster.length > 0) {
    content = (
      <Posts
        headers={headers}
        postsMaster={postsMaster}
        onDeleteHandler={deleteButtonHandler}
        onReset={onResetPostsHandler}
      />
    );
  } else {
    content = (
      <p
        style={{
          textAlign: "center",
          color: "white",
          fontWeight: "bold",
          padding: "20px"
        }}
      >
        No Posts Found! <FaRegFrown />
      </p>
    );
  }

  return (
    <div className={classes.main}>
      <div style={{ textAlign: "center" }}>
        <button onClick={myPosts} className={classes.button}>
          Press Me To Find the Posts
        </button>
      </div>
      <section>{content}</section>
    </div>
  );
}

export default App;
