import React from "react";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import "react-tabs/style/react-tabs.css";
import PostsList from "./PostsList";
import classes from "./Posts.module.css";

function Posts(props) {
  return (
    <Tabs>
      <div className = {classes.adjust}>
        <TabList className={classes.tabs}>
          <Tab>{props.headers[0]}</Tab>
          <Tab>{props.headers[1]}</Tab>
          <Tab>{props.headers[2]}</Tab>
          <Tab>{props.headers[3]}</Tab>
        </TabList>
        <button onClick = {props.onReset} className={classes.button}>Reset</button>
      </div>
      <TabPanel className={classes.tabPanel}>
        <PostsList
          data={props.postsMaster.filter(
            post => post.category === props.headers[0].toLowerCase()
          )}
          deleteHandler = {props.onDeleteHandler}
        />
      </TabPanel>
      <TabPanel className={classes.tabPanel}>
        <PostsList
          data={props.postsMaster.filter(
            post => post.category === props.headers[1].toLowerCase()
          )}
          deleteHandler = {props.onDeleteHandler}
        />
      </TabPanel>
      <TabPanel className={classes.tabPanel}>
        <PostsList
          data={props.postsMaster.filter(
            post => post.category === props.headers[2].toLowerCase()
          )}
          deleteHandler = {props.onDeleteHandler}
        />
      </TabPanel>
      <TabPanel className={classes.tabPanel}>
        <PostsList
          data={props.postsMaster.filter(
            post => post.category === props.headers[3].toLowerCase()
          )}
          deleteHandler = {props.onDeleteHandler}
        />
      </TabPanel>
    </Tabs>
  );
}

export default Posts;
