import React, { useState, useEffect } from "react";
import Card from "../UI/Card";
import classes from "./PostsList.module.css";
import { FaTrashAlt } from "react-icons/fa";

const PostsList = ( props ) => {
  const [postsArray, setPostsArray] = useState([]);
  const onSearchHanlder = event => {
    const searchValue = event.target.value;
    const filteredData = props.data.filter(post => {
      if (searchValue === "") {
        return post;
      } else if (
        post.title.toLowerCase().includes(searchValue.toLowerCase()) ||
        post.userId.toString().includes(searchValue) ||
        post.id.toString().includes(searchValue)
      ) {
        return post;
      }
    });
    setPostsArray(filteredData);
  };
  useEffect(
    function() {
      setPostsArray(props.data);
    },
    [props.data]
  );
  return (
    <section className={classes.posts}>
      <Card>
        <div className={classes.search}>
          <input
            type="text"
            placeholder="Search..."
            onChange={onSearchHanlder}
          />
        </div>
        <ul>
          {postsArray.map((post, key) => (
            <li className={classes.postsList} key={post.id}>
              <div>
                <p>userId: {post.userId}</p>
                <p>id: {post.id}</p>
                <h4>Category: {post.category}</h4>
                <h3>Title: {post.title}</h3>
              </div>
              <div>
                <button
                  className={classes.button}
                  onClick={() => {
                    props.deleteHandler(post.id);
                  }}
                >
                  <FaTrashAlt />
                </button>
              </div>
            </li>
          ))}
        </ul>
      </Card>
    </section>
  );
};

export default PostsList;
